# CampusLore (University of Mindanao, Matina)

Stage 1: design system, landing page and feed with mock data. Theme uses UM's maroon and gold.

## Run locally
1. Install Node.js 20+.
2. `npm install`
3. `npm run dev`  then open the Local URL.
4. On your phone (same Wi-Fi) open the Network URL printed in the terminal.

## Next
Stage 2 adds Supabase (auth, schema, RLS). Copy `.env.example` to `.env` then.
CampusLore is not an official UM service.
