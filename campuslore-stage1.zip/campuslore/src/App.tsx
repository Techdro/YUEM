import { Routes, Route, Navigate } from 'react-router-dom'
import Landing from './pages/Landing'
import Feed from './pages/Feed'
export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/app" element={<Feed />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
