import { Link } from 'react-router-dom'
export default function Logo({ to = '/' }: { to?: string }) {
  return (
    <Link to={to} className="flex items-center gap-2.5" aria-label="CampusLore home">
      <img src="/logo.svg" alt="" className="h-9 w-9" />
      <span className="font-display text-xl font-bold">Campus<span className="text-gold">Lore</span></span>
    </Link>
  )
}
