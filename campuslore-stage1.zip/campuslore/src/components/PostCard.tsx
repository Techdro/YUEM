import { useState } from 'react'
import { Heart, MessageCircle, Share2, Flag, Check } from 'lucide-react'
import type { Item } from '../data/mock'

export default function PostCard({ item }: { item: Item }) {
  const [liked, setLiked] = useState(false)
  const [voted, setVoted] = useState<number | null>(null)
  const [note, setNote] = useState('')
  const total = (item.options ?? []).reduce((s, o) => s + o.votes, 0) + (voted !== null ? 1 : 0)
  const flash = (m: string) => { setNote(m); setTimeout(() => setNote(''), 2000) }
  const share = async () => {
    const url = `${location.origin}/post/${item.id}`
    if (navigator.share) { try { await navigator.share({ title: 'CampusLore', url }) } catch { /* cancelled */ } }
    else { await navigator.clipboard?.writeText(url); flash('Link copied') }
  }
  return (
    <article className="card p-4 sm:p-5">
      <header className="mb-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
        <span className="font-semibold">{item.author}</span>
        <span className="text-muted">{item.campus}</span>
        <span className="chip border-maroon-light/60 text-gold-soft">{item.category}</span>
        <time className="ml-auto text-xs text-muted">{item.time}</time>
      </header>
      <p className="text-[15px] leading-relaxed">{item.text}</p>
      {item.options && (
        <div className="mt-4 space-y-2" role="group" aria-label="Poll options">
          {item.options.map((o, i) => {
            const v = o.votes + (voted === i ? 1 : 0)
            const pct = Math.round((v / total) * 100)
            return (
              <button key={o.label} disabled={voted !== null} onClick={() => setVoted(i)}
                className={`relative w-full overflow-hidden rounded-xl border px-3 py-2.5 text-left text-sm ${voted === i ? 'border-gold' : 'border-line hover:border-gold/60'}`}>
                {voted !== null && <span className="absolute inset-y-0 left-0 bg-maroon/70 transition-[width] duration-700 ease-out" style={{ width: `${pct}%` }} />}
                <span className="relative flex justify-between gap-3"><span>{o.label}</span>{voted !== null && <span className="text-gold-soft">{pct}% · {v}</span>}</span>
              </button>
            )
          })}
          <p className="text-xs text-muted">{voted === null ? 'Vote to see the results.' : `${total} votes in total`}</p>
        </div>
      )}
      <footer className="mt-4 flex items-center gap-1 text-sm text-muted">
        <button onClick={() => setLiked(!liked)} aria-pressed={liked} aria-label="Like" className={`btn-ghost !border-0 !px-2.5 !py-1.5 ${liked ? '!text-gold' : ''}`}>
          <Heart size={17} fill={liked ? 'currentColor' : 'none'} />{item.likes + (liked ? 1 : 0)}
        </button>
        <button aria-label="Comments" className="btn-ghost !border-0 !px-2.5 !py-1.5"><MessageCircle size={17} />{item.comments}</button>
        <button onClick={share} aria-label="Share" className="btn-ghost !border-0 !px-2.5 !py-1.5"><Share2 size={17} />Share</button>
        <button onClick={() => flash('Report noted (demo)')} aria-label="Report" className="btn-ghost !border-0 !px-2.5 !py-1.5 ml-auto"><Flag size={16} /></button>
      </footer>
      {note && <p role="status" className="mt-2 flex items-center gap-1.5 text-xs text-gold"><Check size={14} />{note}</p>}
    </article>
  )
}
