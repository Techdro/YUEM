export type Item = { id: number; kind: 'post' | 'poll'; author: string; campus: string; category: string; text: string; time: string; likes: number; comments: number; options?: { label: string; votes: number }[] }
export const CAMPUSES = ['UM Matina Campus', 'UM Main (Bolton)']
export const items: Item[] = [
  { id: 1, kind: 'poll', author: 'Anonymous Wildcat #231', campus: 'UM Matina Campus', category: 'Campus Life', text: 'Where is the best spot to study between classes?', time: '12m ago', likes: 48, comments: 12, options: [{ label: 'Library', votes: 120 }, { label: 'Canteen', votes: 64 }, { label: 'Hallway benches', votes: 41 }, { label: 'Under the trees', votes: 33 }] },
  { id: 2, kind: 'post', author: 'Anonymous Wildcat #087', campus: 'UM Matina Campus', category: 'College Moments', text: 'Walked into the wrong room, sat through ten minutes of a lecture, and only left when the prof started calling attendance.', time: '1h ago', likes: 91, comments: 23 },
  { id: 3, kind: 'post', author: 'Mika R.', campus: 'UM Matina Campus', category: 'Question', text: 'Anyone know the shortest enrollment line this week? Asking for my sleep schedule.', time: '3h ago', likes: 27, comments: 18 },
  { id: 4, kind: 'poll', author: 'Anonymous Wildcat #412', campus: 'UM Matina Campus', category: 'Discussion', text: 'Rainy day plan: walk through the puddles or wait it out?', time: '5h ago', likes: 35, comments: 9, options: [{ label: 'Walk, my shoes are doomed anyway', votes: 58 }, { label: 'Wait it out', votes: 77 }] },
  { id: 5, kind: 'post', author: 'Anonymous Wildcat #150', campus: 'UM Matina Campus', category: 'Meme', text: 'Me: I will start the project early. Also me, the night before the deadline: a Wildcat at 2 AM.', time: '1d ago', likes: 133, comments: 40 },
]
export const topics = ['Enrollment week', 'Library hours', 'Canteen picks', 'Intramurals', 'Finals survival']
