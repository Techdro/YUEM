import { useMemo, useState } from 'react'
import { Bell, Home, Flame, BarChart3, User, Search, PenLine, GraduationCap, Info } from 'lucide-react'
import Logo from '../components/Logo'
import PostCard from '../components/PostCard'
import { items, topics, CAMPUSES } from '../data/mock'

const tabs = ['For You', 'Trending', 'Latest', 'Polls'] as const
const nav = [{ i: Home, l: 'Home' }, { i: Flame, l: 'Trending' }, { i: BarChart3, l: 'Polls' }, { i: User, l: 'Profile' }]

export default function Feed() {
  const [tab, setTab] = useState<(typeof tabs)[number]>('For You')
  const [q, setQ] = useState('')
  const [text, setText] = useState('')
  const [anon, setAnon] = useState(true)
  const list = useMemo(() => {
    let r = items.filter((x) => x.text.toLowerCase().includes(q.toLowerCase()))
    if (tab === 'Polls') r = r.filter((x) => x.kind === 'poll')
    if (tab === 'Trending') r = [...r].sort((a, b) => b.likes - a.likes)
    return r
  }, [tab, q])

  return (
    <div className="mx-auto grid min-h-screen max-w-6xl gap-6 px-4 pb-24 lg:grid-cols-[200px_1fr_280px] lg:pb-6">
      <aside className="sticky top-0 hidden h-screen flex-col gap-6 py-5 lg:flex">
        <Logo to="/" />
        <nav className="space-y-1" aria-label="Main">{nav.map(({ i: I, l }) => (<a key={l} href="#" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm hover:bg-card hover:text-gold"><I size={18} />{l}</a>))}</nav>
      </aside>

      <main className="py-4">
        <div className="mb-4 flex items-center gap-2 lg:hidden"><Logo /><button aria-label="Notifications" className="btn-ghost ml-auto !p-2"><Bell size={18} /></button></div>
        <div className="mb-4 flex flex-wrap gap-2">
          <label className="card flex flex-1 items-center gap-2 px-3 py-2 text-sm"><Search size={16} className="text-muted" /><span className="sr-only">Search posts</span>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search stories and polls" className="w-full bg-transparent outline-none placeholder:text-muted" /></label>
          <label className="card flex items-center gap-2 px-3 py-2 text-sm"><GraduationCap size={16} className="text-gold" /><span className="sr-only">Campus</span>
            <select className="bg-transparent outline-none">{CAMPUSES.map((c) => <option key={c} className="bg-card">{c}</option>)}</select></label>
        </div>

        <section className="card mb-4 p-4" aria-label="Create post">
          <label className="sr-only" htmlFor="c">Write a story</label>
          <textarea id="c" value={text} onChange={(e) => setText(e.target.value.slice(0, 500))} rows={3} placeholder="What happened on campus today?" className="w-full resize-none bg-transparent text-[15px] outline-none placeholder:text-muted" />
          <p className="mt-2 flex items-start gap-1.5 text-xs text-muted"><Info size={14} className="mt-0.5 shrink-0" />Do not post personal information or accuse identifiable people. Anonymous posts can still be reviewed by moderators.</p>
          <div className="mt-3 flex items-center gap-3">
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={anon} onChange={(e) => setAnon(e.target.checked)} className="accent-[#e6b93a]" />Post as a pseudonym</label>
            <span className="ml-auto text-xs text-muted">{text.length}/500</span>
            <button disabled={!text.trim()} className="btn-gold disabled:opacity-40"><PenLine size={16} />Post</button>
          </div>
        </section>

        <div role="tablist" className="mb-4 flex gap-1 border-b border-line">
          {tabs.map((t) => (<button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`px-3 py-2 text-sm font-semibold ${tab === t ? 'border-b-2 border-gold text-gold' : 'text-muted hover:text-cream'}`}>{t}</button>))}
        </div>
        <div className="space-y-4">
          {list.length ? list.map((x) => <PostCard key={x.id} item={x} />) : <div className="card p-8 text-center text-muted">Nothing matches that search. Try a different word or post the first story.</div>}
        </div>
      </main>

      <aside className="hidden space-y-4 py-5 lg:block">
        <div className="card p-4"><h2 className="mb-3 font-semibold">Trending topics</h2><ul className="space-y-2 text-sm">{topics.map((t) => <li key={t} className="text-muted hover:text-gold">#{t.replace(/\s/g, '')}</li>)}</ul></div>
        <div className="card p-4"><h2 className="mb-3 font-semibold">Popular polls</h2><ul className="space-y-2 text-sm">{items.filter((x) => x.kind === 'poll').map((p) => <li key={p.id} className="text-muted">{p.text}</li>)}</ul></div>
      </aside>

      <nav aria-label="Mobile" className="fixed inset-x-0 bottom-0 z-10 flex justify-around border-t border-line bg-ink/95 py-2 backdrop-blur lg:hidden" style={{ paddingBottom: 'max(0.5rem, env(safe-area-inset-bottom))' }}>
        {nav.map(({ i: I, l }) => (<a key={l} href="#" className="flex flex-col items-center gap-0.5 px-3 text-xs text-muted hover:text-gold"><I size={20} />{l}</a>))}
      </nav>
    </div>
  )
}
