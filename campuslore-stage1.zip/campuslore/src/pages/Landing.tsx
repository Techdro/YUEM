import { Link } from 'react-router-dom'
import { BarChart3, PenLine, ShieldCheck, TrendingUp } from 'lucide-react'
import Logo from '../components/Logo'
import PostCard from '../components/PostCard'
import { items, topics } from '../data/mock'

const steps = [
  { icon: PenLine, t: 'Share a story', d: 'Post a moment, a question or a meme, under your name or a pseudonym.' },
  { icon: BarChart3, t: 'Run a poll', d: 'Ask the whole campus anything and watch the votes come in.' },
  { icon: TrendingUp, t: 'See what is trending', d: 'Fresh and popular posts rise to the top of the feed.' },
]
export default function Landing() {
  return (
    <div className="min-h-screen">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <Logo />
        <div className="flex gap-2"><Link to="/app" className="btn-ghost">Log in</Link><Link to="/app" className="btn-gold hidden sm:inline-flex">Join your campus</Link></div>
      </nav>
      <header className="mx-auto grid max-w-6xl gap-10 px-4 pb-16 pt-10 lg:grid-cols-[1.1fr_1fr] lg:items-center">
        <div>
          <p className="chip mb-5 inline-block text-gold-soft">Made for University of Mindanao, Matina Campus</p>
          <h1 className="text-5xl font-extrabold leading-[1.02] sm:text-6xl">Your campus has stories.</h1>
          <p className="mt-3 font-display text-xl text-gold sm:text-2xl">Make them legendary.</p>
          <p className="mt-5 max-w-md text-muted">Polls, memes and honest campus moments from fellow Wildcats, with moderators keeping it safe.</p>
          <div className="mt-8 flex flex-wrap gap-3"><Link to="/app" className="btn-gold">Explore CampusLore</Link><Link to="/app" className="btn-ghost">Join your campus</Link></div>
        </div>
        <div className="space-y-4 lg:rotate-1"><PostCard item={items[0]} /><PostCard item={items[1]} /></div>
      </header>
      <section className="border-y border-line bg-card/50">
        <div className="mx-auto max-w-6xl px-4 py-10">
          <h2 className="text-2xl font-bold">Trending on campus</h2>
          <div className="mt-4 flex flex-wrap gap-2">{topics.map((t) => <span key={t} className="chip text-cream">#{t.replace(/\s/g, '')}</span>)}</div>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-3xl font-bold">How it works</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {steps.map(({ icon: I, t, d }) => (<div key={t} className="card p-5"><I className="mb-3 text-gold" /><h3 className="text-lg font-semibold">{t}</h3><p className="mt-1 text-sm text-muted">{d}</p></div>))}
        </div>
        <p className="mt-8 flex items-start gap-2 text-sm text-muted"><ShieldCheck size={18} className="mt-0.5 shrink-0 text-gold" />Anonymous does not mean unmoderated. CampusLore is not an official UM service and does not verify students.</p>
      </section>
      <footer className="border-t border-line px-4 py-8 text-sm text-muted">
        <div className="mx-auto flex max-w-6xl flex-wrap gap-x-6 gap-y-2">
          <span>About</span><span>Community Guidelines</span><span>Privacy Policy</span><span>Contact</span>
        </div>
      </footer>
    </div>
  )
}
