/** UM-inspired palette: maroon + gold, cream text */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: {
      ink: '#170a0d', card: '#241015', line: '#3d1d25',
      maroon: { DEFAULT: '#7b1527', light: '#a31d36' },
      gold: { DEFAULT: '#e6b93a', soft: '#f3d98a' },
      cream: '#f6ebd2', muted: '#b7a3a0',
    },
    fontFamily: { display: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'], sans: ['Figtree', 'system-ui', 'sans-serif'] },
  } },
}
